const nodeVersion = process.version;
console.log("Node.js version:", nodeVersion);